#' dcibinformatics.
#'
#' @name dcibioinformatics
#' @docType package
#' @useDynLib dcibioinformatics
#' @importFrom Rcpp evalCpp
NULL
