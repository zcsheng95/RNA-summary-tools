## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = FALSE,
  results = "asis",
  fig.show = "hold"
)

## ----setup---------------------------------------------------------------
library(dcibioinformatics)

## ----star summary, echo=TRUE---------------------------------------------
rootdir <- dirname(system.file("extdata","Rh28-Ctrl-HA-FLAG-1_S1/",package = "dcibioinformatics",mustWork = TRUE))
starsumm <- getSTARsum(rootdir = rootdir)
knitr::kable(starsumm,align = 'c',caption = 'STAR Alignment Summary')

