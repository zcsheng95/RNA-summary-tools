## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = FALSE,
  results = "asis",
  fig.show = "hold",
  fig.width = 10,
  fig.height = 5,
  fig.align = 'center'
)

## ----setup---------------------------------------------------------------
library(dcibioinformatics)

## ----star summary, echo=TRUE---------------------------------------------
rootdir <- dirname(system.file("extdata","Rh28-Ctrl-HA-FLAG-1_S1/",package = "dcibioinformatics",mustWork = TRUE))
starsumm <- getSTARsum(rootdir = rootdir)
knitr::kable(starsumm[1:10,],align = 'c',caption = 'STAR Alignment Summary')

## ----star counts,echo = TRUE---------------------------------------------
starcounts <- getSTARcounts(rootdir = rootdir, strand = "second")
knitr::kable(starcounts[1:10,],align = 'c',caption = 'STAR Counts Summary')

## ----picard counts, echo = TRUE------------------------------------------
picounts <- getPIcounts(rootdir = rootdir)
knitr::kable(picounts,align = 'c',caption = 'Picard Counts Summary')


## ----counting reads bar plot, echo=TRUE----------------------------------
plotAlignment(starcounts,type = "HTSeq",textsize = 3)

## ----counting bases bar plot, echo = TRUE--------------------------------
plotAlignment(picounts,type = "Picard",textsize = 2)


